import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-7ANLYX27.js";
import "./chunk-AHR2KOK7.js";
import "./chunk-U6NMLMAW.js";
import "./chunk-MCHHPREQ.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-7HR2P5MZ.js";
import "./chunk-OGB5QJRD.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-4XCMFOR4.js";
import "./chunk-YDH5J5RV.js";
import "./chunk-BQSIGNSM.js";
import "./chunk-6XISFZPP.js";
import "./chunk-WNPMEE2K.js";
import "./chunk-OGW7HQS4.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
