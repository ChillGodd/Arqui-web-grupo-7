import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Herramientas } from '../models/herramientas.model';
import { Subject,throwError } from 'rxjs';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

const base_url = environment.base;

@Injectable({
  providedIn: 'root'
})
export class HerramientasService {
  private url = `${base_url}/herramientas`;
  private listaCambio=new Subject<Herramientas[]>()

  constructor(private http: HttpClient) {}

  list() {
    return this.http.get<Herramientas[]>(this.url).pipe(
      catchError(this.handleError)
    );
  }
  insert(herramientas:Herramientas){
    return this.http.post(this.url,herramientas).pipe(
      catchError(this.handleError)
    );
  }
  getList(){
    return this.listaCambio.asObservable();
  }
  setList(listaNueva:Herramientas[]){
    this.listaCambio.next(listaNueva)
  }
  delete(id: number) {
    return this.http.delete(`${this.url}/${id}`).pipe(
      catchError(this.handleError)
    );
  }
  listId(id:number){
    return this.http.get<Herramientas>(`${this.url}/${id}`).pipe(
      catchError(this.handleError)
    );
  }
  update(herramientas: Herramientas, id: number){
    return this.http.put(`${this.url}/${id}`, herramientas).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error.message);
    return throwError('Something went wrong; please try again later.');
  }
}