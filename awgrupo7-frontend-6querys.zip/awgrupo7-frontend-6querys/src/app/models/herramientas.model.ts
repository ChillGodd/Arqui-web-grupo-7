import { Proyecto } from "./proyectos.model";

export class Herramientas {
    idHerramienta: number = 0;
    nombre: string = '';
    descripcion: string = '';
    proyecto:Proyecto=new Proyecto();
  }
 