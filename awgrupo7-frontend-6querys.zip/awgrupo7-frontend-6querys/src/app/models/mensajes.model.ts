
export class Mensajes {
  idMensaje: number = 0;
  contenido: string = '';
  fecha: Date = new Date();
  leido: boolean = false;
  userId: number = 0;  
} 

