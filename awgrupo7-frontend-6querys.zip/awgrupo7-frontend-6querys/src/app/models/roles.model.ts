export class Roles {
  idRol: number = 0;
  nombre: string = '';
  descripcion: string = '';
}