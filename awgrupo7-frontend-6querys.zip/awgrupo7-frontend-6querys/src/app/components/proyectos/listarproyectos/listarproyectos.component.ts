import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { ProyectosService } from '../../../services/proyectos.service'; // Ajusta la ruta según tu estructura
import { Proyecto } from '../../../models/proyectos.model'; // Ajusta la ruta según tu estructura
import { MatIconModule } from '@angular/material/icon';
import { RouterModule, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-listarproyectos',
  standalone: true,
  imports: [MatTableModule, MatIconModule, RouterModule, MatPaginatorModule,CommonModule],
  templateUrl: './listarproyectos.component.html',
  styleUrls: ['./listarproyectos.component.css']
})
export class ListarproyectosComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['proyectoID', 'nombre', 'descripcion', 'estado', 'fechaInicio', 'fechaTermina', 'presupuesto', 'user', 'accion01', ];
  dataSource: MatTableDataSource<Proyecto> = new MatTableDataSource();

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private proyectosService: ProyectosService) {}

  ngOnInit(): void {
    this.proyectosService.list().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
    this.proyectosService.getList().subscribe((data) => {
      this.dataSource = new MatTableDataSource(data);
    });
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  eliminar(id: number) {
    const confirmacion = confirm('¿Estás seguro de que deseas eliminar este rol?');
    if (confirmacion) {
      this.proyectosService.delete(id).subscribe(() => {
        this.proyectosService.list().subscribe((data) => {
          this.proyectosService.setList(data);
        });
      });
    }
  }
}