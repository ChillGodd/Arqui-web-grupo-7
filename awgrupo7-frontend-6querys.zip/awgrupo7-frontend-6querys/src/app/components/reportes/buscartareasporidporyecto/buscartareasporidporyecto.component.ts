import { Component, OnInit, ViewChild } from '@angular/core';
import { Tareas } from '../../../models/tareas.model';
import { TareasService } from '../../../services/tareas.service';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';

@Component({
  selector: 'app-buscartareasporidporyecto',
  standalone: true,
  imports: [FormsModule,RouterLink ,CommonModule,MatTableModule,
    MatIconModule,
    RouterModule,
    MatPaginatorModule,],
  templateUrl: './buscartareasporidporyecto.component.html',
  styleUrl: './buscartareasporidporyecto.component.css'
})
export class BuscartareasporidporyectoComponent implements OnInit{
  displayedColumns: string[] = [
    'idTarea', 
    'nombre', 
    'descripcion', 
    'horasEmpleadas', 
    'estado', 
    'fechaLimite', 
    'proyecto', 
    'nombreUser', 
  ];
  tareas: Tareas[] = [];
  nombre: string = '';
  idProyecto: number = 0;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  dataSource: MatTableDataSource<Tareas> = new MatTableDataSource();

  constructor(private tareasService: TareasService) {}

  ngOnInit() {
    this.cargarTareas();
  }

  cargarTareas() {
    this.tareasService.listbyidProyecto(1).subscribe((data) => {
      this.tareas = data;
      this.dataSource.data = this.tareas;
    });
  }
  
  buscarTareas() {
    if (this.idProyecto > 0) {
      this.tareasService.listbyidProyecto(this.idProyecto).subscribe((data) => {
        if (data.length > 0) {
          this.tareas = data;
          this.dataSource.data = this.tareas; 
        } else {
          alert('No se encontraron tareas para este proyecto.');  
          this.tareas = [];  
          this.dataSource.data = this.tareas; 
        }
      });
    } else {
      alert('ID de proyecto no válido'); 
      this.tareas = [];  
      this.dataSource.data = this.tareas; 
    }
  }
}
  



  

